<?php

include('./functions.php');
include('./data.php');

$product = null;

foreach($products as $item) {
    if($item['id'] == $_GET['id']){
        $product=$item;
        break;
    }
    
}

if(!$product){
    http_response_code(404);
    die();
}

print_r($product);