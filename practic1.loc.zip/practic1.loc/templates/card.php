


            <div class="card">
                <img class="img" src="<?php echo $image ?>" />
                <h3><a href="/product.php?id=<?php echo $id ?>"><?php echo $title ?></a></h3>
                <p><?php echo $price ?>$</p>
            </div>