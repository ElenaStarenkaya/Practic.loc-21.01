<?php 

$products = [
    [
        "id" => 1,
        "title" => 'Шляпа',
        "price" => 7,
        "image" => '/img/hat.jpg'
    ],
    [
        "id" => 2,
        "title" => 'Футболка',
        "price" => 5,
        "image" => '/img/tshirt.jpg'
    ],
    [
        "id" => 3,
        "title" => 'Рубашка',
        "price" => 1,
        "image" => '/img/shirt.jpg'
    ],
    [
        "id" => 4,
        "title" => 'Шорты',
        "price" => 2,
        "image" => '/img/pants.jpg'
    ],
    [
        "id" => 5,
        "title" => 'Ботинки',
        "price" => 12,
        "image" => '/img/boots.jpg'
    ],
    [
        "id" => 6,
        "title" => 'Юбка',
        "price" => 5,
        "image" => '/img/skirt.jpg'
    ],
];