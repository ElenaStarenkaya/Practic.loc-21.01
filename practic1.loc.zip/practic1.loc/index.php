<?php

include('./functions.php');
include('./data.php');

$cards_tpl = '';

foreach($products as $product) {  //перебираем массив products, получаем 6 карточек в html
$cards_tpl .= get_template('./templates/card.php', $product);
}

$layout_tpl = get_template('./templates/layout.php', ['content' => $cards_tpl]); //создаем шаблон страницы

echo $layout_tpl; // выводим шаблон страницы на экран